<?php

	mysql_connect("localhost", "root", "Familiar671");

	$userFirstName = mysql_real_escape_string($_POST['userFirstName']);
	$userLastName = mysql_real_escape_string($_POST['userLastName']);
	$userDob = mysql_real_escape_string($_POST['userDob']);
	$userPostalZip = mysql_real_escape_string($_POST['userPostalZip']);
		
	if ($userFirstName==NULL)
		echo "* Please enter your first name.<br />";
	if ($userLastName==NULL)
		echo "* Please enter your last name.<br />";
	if ($userDob==NULL)
		echo "* Please enter your date of birth.<br />";
	if ($userPostalZip==NULL)
		echo "* Please enter your mailing address' zip code.";
		
	else
	{	
		$conditions = "FROM voters.2013aug30_alpha WHERE name LIKE '%$userLastName, $userFirstName%' AND dob='$userDob' AND zip LIKE '%$userPostalZip%'";
		
		$voterName = mysql_query("SELECT name $conditions");
		$voterName_num_rows = mysql_num_rows($voterName);
		
		$voterDob = mysql_query("SELECT dob $conditions");
		$voterDob_num_rows = mysql_num_rows($voterDob);
		//format for echo
		$userDobEcho = DateTime::CreateFromFormat('Y-m-d', $userDob);
			
		$voterPostalVillage = mysql_query("SELECT village $conditions");
		$voterPostalVillage_num_rows = mysql_num_rows($voterPostalVillage);
		
		$voterPostalZip = mysql_query("SELECT zip $conditions");
		$voterPostalZip_num_rows = mysql_num_rows($voterPostalZip);
		
		$voterPrecinct = mysql_query("SELECT precinct $conditions");
		$voterPrecinct_num_rows = mysql_num_rows($voterPrecinct);
		
		if ($voterName_num_rows==0 AND $voterDob_num_rows==0)
			echo "Sorry. The data you entered shows that ".ucwords(strtolower($userFirstName))." ".ucwords(strtolower($userLastName)).", born on ". $userDobEcho->format('m-d-Y')."
			 and receiving mail in zip-code $userPostalZip is NOT currently registered to vote in Guam.";
		else 
		{
			$voterName = mysql_result($voterName, 0);
			$voterDob = mysql_result($voterDob, 0);
			// format for echo
			$voterDobEcho = DateTime::CreateFromFormat('Y-m-d', $voterDob);
			$voterPostalVillage = mysql_result($voterPostalVillage, 0);
			$voterPostalZip = mysql_result($voterPostalZip, 0);
			$voterPrecinct = mysql_result($voterPrecinct, 0);
			echo "YES. ".ucwords(strtolower($voterName)).", born ". $voterDobEcho->format('m-d-Y')."  and receiving mail in the village of ".ucwords(strtolower($voterPostalVillage))." - with zip-code $voterPostalZip, IS currently registered to vote at precinct $voterPrecinct.";
		}
	}
?>