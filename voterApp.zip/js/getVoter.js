function get() {
	$.post('data.php', { userFirstName: userInfo.firstName.value, userLastName: userInfo.lastName.value, userDob: userInfo.dob.value, userPostalZip: userInfo.postalZip.value },
		function(output) {
			$('#displayResult').html(output).show();
		});
}